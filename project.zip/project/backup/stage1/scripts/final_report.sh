REPORT=reports/final_report_$(date +%Y%m%d_%H%M%S).txt

echo "=== Fianl report in system  ===" > "$REPORT"
echo "Date: $(date)" >> "$REPORT"
echo "User: $(whoami)" >> "$REPORT"
echo "System Name: $(hostname)" >> "$REPORT"
echo "Kernel: $(uname -r)" >> "$REPORT"


echo -e "\n--- Memory ---" >> "$REPORT"
free -h >> "$REPORT"

echo -e "\n--- Disk ---" >> "$REPORT"
df -h >> "$REPORT"

echo -e "\n--- Projects File ---" >> "$REPORT"
find ~/project -type f | wc -l >> "$REPORT"

echo -e "\n--- Active Process (first 10 one) ---" >> "$REPORT"
ps aux --sort=-%cpu | head -n 10 >> "$REPORT"

echo -e "\n--- Network Info ---" >> "$REPORT"
ip a >> "$REPORT"

echo -e "\n--- LOG Summary ---" >> "$REPORT"
grep -c "ERROR" ~/project/reports/sample.log >> "$REPORT"

echo -e "\n--- Backup Status ---" >> "$REPORT"
ls -l ~/project/backup >> "$REPORT"

echo "Reports Are created successfully: $REPORT"
