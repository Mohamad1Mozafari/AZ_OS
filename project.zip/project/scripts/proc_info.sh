echo "PID of current process: $$"
echo "PID of parent process: $PPID"
echo "Running for 10 seconds..."
sleep 10
echo "Execution ended"
