echo "hello from script"
